lib = require("lib")

require("prototypes.technology")
require("prototypes.recipe")
require("prototypes.entity")
require("prototypes.item")

