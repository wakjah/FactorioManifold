# Manifold Pumps Changelog

# # Version 0.0.1
- Initial release for 0.16

# # Version 0.0.2
- Updates to work on 0.17
- Added thumbnail
